|||||||||||||||||||||||||||||||||||
|X Remote Administration tool V2.0|
|||||||||||||||||||||||||||||||||||
 
X is a remote administrative tool created on 20th January 2004.

This program was created for educational purposes, the author cannot be held responsible for your actions.

New version update means...
Fixed Keylogger
New Options added
Stable server
more fun!
 _               
 /_`_  /._ _/__  _
._//_//// // /_'/ 
  /               