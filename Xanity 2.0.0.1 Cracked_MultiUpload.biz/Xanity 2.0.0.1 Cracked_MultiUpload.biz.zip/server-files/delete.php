<?php
$file = $_GET['file'];
unlink($file);
?>