SkD RAT v2.0 BETA
------------------------------------------------------------------
WARNING: The author of the program/software is in no way responsible for any actions caused by you using this program!
------------------------------------------------------------------

Well, this is my new version of my RAT. I think there are lots of changes since the last version (1.5)!
The server is rewritten completely in a different language (Delphi), meaning that you dont need the Visual Basic runtimes anymore, and no more WinSock OCX is needed as Im using the WinSock API. This version is completely based on reverse-connection which makes the server connect to your computer instead of you connecting to a remote computer (direct connect).

Here is a list of what my RAT currently features:
-FireWall ByPass (Tested on ZoneLabs ZoneAlarm 6.0)
-SDTRestore (Unhook Kernel+User Mode APIs)
-In-Built RootKit (Hide Files,etc)
-Server Multi-Threaded (While Downloading, you can do other functions!)
-Registry Manager (More like a Registry Viewer as there is no delete,create,edit keys..)
-Services Manager
-MessageBox
-URL Download 
-Mouse Control
-Control Panel
-Crazy Mouse
-Send Keys
-Power Options (Log Off,ShutDown,Reboot..)
-MsN Passwords (Grab passwords for MSN messenger,Yahoo! messenger,ICQ,etc)
-Offline/Online Keylogger
-Window Manager
-Task (Process) Manager
-Hide StartButton/Show StartButton
-Scripting
-FileManager
-ClipBoard Manager
-PC Information
-Mass Download (Send a command to all servers on your reverse-connected list to download a file + execute from any URL)

As this version of my RAT is still in the BETA stage, I inform you that you man encounter errors and bugs.

Please report bugs/errors/requests at: skdrat@hotmail.com
WebSite:http://skdpro.com

SkD RAT v2.0 B Undetectable/Professional Versions for sale! Contact Me.

Thank you,
SkD.

               SS                                    
              SSSS                                   
              SSSS                                   
              SSSS                                   
             SSSSS                                   
            SSSSSS                                   
            SSSSS                                    
           SSSSS                                     
          SSSSSS                                     
         SSSSSS                                      
        SSSSSS                      SSSS             
        SSSSS      SS              SSSSSSS           
       SSSSS      SSSS    SS       SSSSSSSS          
      SSSSSS      SSSS  SSSSS      SSSSSSSSS         
      SSSSS       SSSSSSSSSSS      SSSSSSSSSS        
      SSSS        SSSSSSSSSSS      SSSS SSSSSS       
     SSSSS        SSSSSSSSSS       SSSS  SSSSS       
     SSSSS        SSSSSSSS         SSSS   SSSS       
     SSSS         SSSSSS           SSSS   SSSSS      
     SSSSS        SSSSS            SSSS   SSSSS      
     SSSSSSSS     SSSSSS           SSSS    SSSS      
      SSSSSSSSS   SSSSSSS          SSSS    SSSS      
       SSSSSSSSS  SSSSSSSS         SSSS    SSSS      
        SSSSSSSS  SSSSSSSSS        SSSS   SSSSS      
           SSSSSS SSSSSSSSSS       SSSS   SSSSS      
           SSSSSS SSSS SSSSSS      SSSS  SSSSS       
           SSSSSS SSSS  SSSSSS     SSSS SSSSSS       
          SSSSSS   SS   SSSSSS     SSSS SSSSS        
         SSSSSSS          SSSS     SSSSSSSSS         
         SSSSSS            SS      SSSSSSSSS         
        SSSSS                      SSSSSSSS          
        SSSSS                      SSSSSSS           
        SSSS                        SSSSS            
        SSSS                         SSS             
       SSSSS                                         
       SSSSS                                         
      SSSSS                                          
      SSSSS                                          
      SSSS                                           
       SS  