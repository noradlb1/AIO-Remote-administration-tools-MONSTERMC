Traffix is a Trojan Coded by me (affix) that has universal Plug 'n' Play allowing the Client to automatically forward the required ports. So 100% newbie friendly :)

Coded in Visual Basic but meh :P works

May recode in delphi / c++ one day :P
Features

SIN Console - Basically the connection page of the RAT.
+SIN Notify
+Rev Connect
+uPnP!!

Fun Stuff - Oh boy, this RAT is just full of fun little shit you can do
+Set/Get Clipboard
+Swap/Fix Mouse Buttons
+Set/Get Timeate
+Open/Close CD-ROM Tray
+Show/Hide Desktop
+Show/Hide Taskbar
+Show/Hide Start Button
+Show/Hide System Clock
+Get/Set/Restore System Colors
+Change Wallpaper
+Send Error Message
+Screenshot

File Manager

Process Manager

Keylogger

Windows Enumerator

Error Dialogs

Windows Management
+Shutdown
+Logoff
+Restart
+Get System Info
+Retrieve DOS Output


Server is compressed with UPX

In Development :

Java Server
Webcam Capture